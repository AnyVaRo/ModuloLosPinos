/** @type {import('next').NextConfig} */
const nextConfig = {
    images:{
        remotePatterns:[{hostname:'yyftwncsle080vd5.public.blob.vercel-storage.com'}]
    }
}

module.exports = nextConfig
